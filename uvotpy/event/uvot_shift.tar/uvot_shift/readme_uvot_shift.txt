UVOT SHIFT 

Program to aspect correct UVOT images from Simon, Mat, and Sam. 
Edited by Paul to remove some old stuff. 

The structure is 
  * perl script uvot_shift_image
  * csh script uvot_shift_individual
  * gfortran executable position_shift_uvot_images

The environment variable $UVOTSHIFT needs to point at the 
uvotshift bin directory (below this directory), so that 
  file $UVOTSHIFT/swuphot20041120v999.fits 
outputs 
  <...>: FITS image data, 8-bit, character or unsigned binary integer

This program makes use of the zeropoints in the calibration 
file "swuphot20041120v999.fits" (hardcoded location in the csh 
script) which has been modified to include a ZP for the grisms. 

The vgrism ZP is a dummy value, and that for the clocked 
grisms will depend to some degree on how close the zeroth order 
is to the occulted area as the sensitivity drops.  

To do: create an updated attitude file using the shifts. 
Perhaps this should be a final step after the shifts are all 
known. An example correction file *.asp is copied into the directory.

2023-12-07 NPMK
changed the swuphot file :
cp swuphot20041121v999.fit -> swuphot20041121v999.old.fit
cp /sciencesoft/CALDB/data/swift/uvota/bcf/phot/swuphot20041120v108.fits swuphot20041120v999.fits

