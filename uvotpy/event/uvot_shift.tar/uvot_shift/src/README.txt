2015-03-07 NPMK - Paul Kuin

position_shift_uvot_images was written originally by Mat andr Simon) and is in F90. 

The program included originally the option for generating plots, so for compilation
the pgplot libraries are needed. This stuff has been removed (2015-04-25)

Mat wrote a shell script to provide the input files to the program, and Sam 
wrote a perl script to take over the USNO catalog call to scat. 


